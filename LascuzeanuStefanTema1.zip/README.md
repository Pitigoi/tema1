# Tema 1 - Lăscuzeanu Ștefan-Andrei

Inspirat din codul sursa stdlib din directorul [src freebsd](https://github.com/freebsd/freebsd-src)
Comenzile pentru make-uri:
 - Windows `nmake -f Makefile.win`
 - Linux &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; `make`
