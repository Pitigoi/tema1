#include "so_stdio.h"

typedef struct _so_file
{
	#if defined(__linux__)
	int fd;
	int pid;
	int flags;
	#elif defined(_WIN32)
	HANDLE fd;
	PROCESS_INFORMATION process;
	#endif

	int rerror;
	int werror;

	char buffer[SO_BUFSIZE];
	int pos;
	int bufmode;//0 if read 1 if write
	int size;
} SO_FILE;

#if defined(__linux__)

ssize_t wbytes(int fd, const void* buf, size_t count)
{
	size_t totalbytes = 0;
	while (totalbytes < count) {
		ssize_t b = write(fd, buf + totalbytes,	count - totalbytes);
		if (b <= 0) return -1;
		totalbytes += b;
	}

	return totalbytes;
}

int dump_in_buffer(SO_FILE* stream)
{
	int dumped;

	dumped = read(stream->fd, stream->buffer, SO_BUFSIZE);
	if (dumped <= 0) {
		stream->rerror = SO_EOF;
		return dumped;
	}

	stream->size = dumped;
	stream->pos = 0;
	stream->rerror = 0;

	return dumped;
}

int dump_out_buffer(SO_FILE* stream)
{
	int dumped;

	dumped = wbytes(stream->fd, stream->buffer, stream->pos);
	stream->pos = 0;

	if (dumped <= 0) 
		stream->werror = SO_EOF;

	return dumped;
}

int so_fileno(SO_FILE* stream)
{
	return stream->fd;
}

SO_FILE* so_fopen(const char* pathname, const char* mode)
{

	SO_FILE* stream = (SO_FILE*)malloc(sizeof(SO_FILE));
	mode_t mode2 = S_IRWXU | S_IRWXG | S_IRWXO;
	if (strcmp(mode, "r") == 0) {
		stream->flags = O_RDONLY;
		stream->bufmode = 0;
	}
	else if (strcmp(mode, "r+") == 0) {
		stream->flags = O_RDWR | O_CREAT;
		stream->bufmode = 0;
	}
	else if (strcmp(mode, "w") == 0) {
		stream->flags = O_WRONLY | O_CREAT | O_TRUNC;
		stream->bufmode = 1;
	}
	else if (strcmp(mode, "w+") == 0) {
		stream->flags = O_RDWR | O_CREAT | O_TRUNC;
		stream->bufmode = 1;
	}
	else if (strcmp(mode, "a") == 0){
		stream->flags = O_WRONLY | O_CREAT | O_APPEND;
		stream->bufmode = 1;
	}
	else if (strcmp(mode, "a+") == 0) {
		stream->flags = O_RDWR | O_CREAT | O_APPEND;
		stream->bufmode = 1;
	}
	else
	{
		free(stream);
		return NULL;
	}
	if (stream->flags & O_CREAT)
		stream->fd = open(pathname, stream->flags, mode2);
	else stream->fd = open(pathname, stream->flags);

	return stream;
}

int so_fclose(SO_FILE* stream)
{
	int val;

	if (stream->bufmode==1 && stream->pos != 0) {
		val = dump_out_buffer(stream);
		if (val <= 0) {
			free(stream);
			return val;
		}
	}
	val = close(stream->fd);
	if (val < 0)
		return -1;
	free(stream);

	return 0;
}

size_t so_fread(void* ptr, size_t size, size_t nmemb, SO_FILE* stream)
{
	if (stream->bufmode == 1)
	{
		if (stream->flags & O_RDONLY)
		{
			dump_out_buffer(stream);
			stream->pos = 0;
			stream->bufmode = 0;
		}
		else
			return -1;
	}
	int i,offset = 0,dumped;
	size_t to_read, membct = 0;

	for (i = 0; i < nmemb; i++) {
		size_t bytes_read_now = 0;

		while (bytes_read_now < size) {
			if (stream->pos == stream->size) {
				dumped = dump_in_buffer(stream);
				if (dumped < 0)
					return 0;
				if (dumped == 0)
					return membct;
			}

			to_read = size;
			if (stream->size - stream->pos < to_read)
				to_read = stream->size - stream->pos;

			memcpy(ptr + offset, stream->buffer + stream->pos,to_read);
			stream->pos += to_read;
			bytes_read_now += to_read;
			offset += to_read;
		}

		if (bytes_read_now > 0)
			membct++;
	}

	return membct;
}

size_t so_fwrite(const void* ptr, size_t size, size_t nmemb, SO_FILE* stream)
{
	if (stream->bufmode == 0)
	{
		if (stream->flags & O_WRONLY)
		{
			dump_in_buffer(stream);
			stream->pos = 0;
			stream->size = 0;
			stream->bufmode = 1;
		}
		else
			return -1;
	}
	
	int i,offset = 0,dumped;
	size_t to_write,membct = 0;

	for (i = 0; i < nmemb; i++) {
		size_t bytes_wrote_now = 0;

		while (bytes_wrote_now < size) {
			if (stream->pos == SO_BUFSIZE) {
				dumped = dump_out_buffer(stream);
				if (dumped <= 0)
					return 0;
			}

			to_write = size;
			if (SO_BUFSIZE - stream->pos < to_write)
				to_write = SO_BUFSIZE - stream->pos;

			memcpy(stream->buffer + stream->pos, ptr + offset,
				to_write);
			stream->pos += to_write;
			bytes_wrote_now += to_write;
			offset += to_write;
		}

		if (bytes_wrote_now > 0)
			membct++;
	}

	return membct;
}

int so_fseek(SO_FILE* stream, long offset, int whence)
{
	int moved,check;

	if (stream->pos != 0 && stream->bufmode==1) {
		check = dump_out_buffer(stream);
		if (check <= 0)
			return -1;
		stream->pos = 0;
	}

	if (whence == SEEK_CUR)
		offset -= (stream->size - stream->pos);
	stream->pos = 0;
	stream->size = 0;

	moved = lseek(stream->fd, offset, whence);
	if (moved == -1)
		return -1;
	return 0;
}

long so_ftell(SO_FILE* stream)
{
	int pos;

	pos = lseek(stream->fd, 0, SEEK_CUR);
	if (pos == -1)
		return -1;

	if (stream->bufmode==0 && stream->size != 0)
		pos = pos - (stream->size - stream->pos);

	if (stream->bufmode == 0 && stream->pos != 0)
		pos = pos + stream->pos;

	return pos;
}

int so_fputc(int c, SO_FILE* stream)
{
	if (stream->bufmode == 0)
	{
		if (stream->flags & O_WRONLY)
		{
			dump_in_buffer(stream);
			stream->pos = 0;
			stream->size = 0;
			stream->bufmode = 1;
		}
		else
			return -1;
	}
	int check;

	if (stream->bufmode == 1 && stream->pos == SO_BUFSIZE) {
		check = dump_out_buffer(stream);
		if (check <= 0)
			return -1;
	}

	stream->buffer[stream->pos] = (char)c;
	(stream->pos)++;

	return c;
}

int so_fgetc(SO_FILE* stream)
{
	if (stream->bufmode == 1)
	{
		if (stream->flags & O_RDONLY)
		{
			dump_out_buffer(stream);
			stream->pos = 0;
			stream->bufmode = 0;
		}
		else
			return -1;
	}
	int check;
	char c;

	if (stream->pos == stream->size) {
		check = dump_in_buffer(stream);
		if (check <= 0)
			return -1;
	}

	c = stream->buffer[stream->pos];
	(stream->pos)++;

	return c;
}

int so_fflush(SO_FILE* stream)
{
	if (stream->bufmode == 0)
	{
		if (stream->flags & O_WRONLY)
		{
			dump_in_buffer(stream);
			stream->pos = 0;
			stream->size = 0;
			stream->bufmode = 1;
		}
		else
			return -1;
	}

	int dumped;

	if (stream->pos != 0) {
		dumped = dump_out_buffer(stream);
		if (dumped <= 0)
			return -1;
	}

	return 0;
}

SO_FILE* so_popen(const char* command, const char* type)
{
	SO_FILE* stream = (SO_FILE*)malloc(sizeof(SO_FILE));
	int check;
	stream->pos = stream->size = 0;
	if (strcmp(type, "r") == 0)
	{
		stream->flags = O_RDONLY;
		stream->bufmode = 0;
	}
	else if (strcmp(type, "w") == 0) {
		stream->flags = O_WRONLY;
		stream->bufmode = 1;
	}
	else {
		free(stream);
		return NULL;
	}
	int p[2];
	pipe(p);

	if (stream->flags == O_RDONLY)
		stream->fd = p[PIPE_READ];
	else
		stream->fd = p[PIPE_WRITE];

	int pid = fork();

	if (pid == -1)
	{
		close(p[PIPE_READ]);
		close(p[PIPE_WRITE]);
		free(stream);

		return NULL;
	}
	else if(pid==0)
	{
		if (stream->flags == O_RDONLY) {
			close(p[PIPE_READ]);
			dup2(p[PIPE_WRITE], STDOUT_FILENO);
		}
		else {
			close(p[PIPE_WRITE]);
			dup2(p[PIPE_READ], STDIN_FILENO);
		}

		check = execl("/bin/bash", "-c", command, NULL);
		//returneaza doar in caz de eroare
		if (check)
			return NULL;
	}
	stream->pid = pid;

	if (stream->flags == O_RDONLY)
		close(p[PIPE_WRITE]);
	else
		close(p[PIPE_READ]);
	return stream;
}

int so_pclose(SO_FILE* stream)
{
	int status, ret;
	int pid = stream->pid;
	int fd = stream->fd;

	if (stream->bufmode==1 && stream->pos != 0) {
		ret = dump_out_buffer(stream);
		if (ret <= 0) {
			free(stream);
			return ret;
		}
	}

	free(stream);
	close(fd);

	if (waitpid(pid, &status, 0) < 0)
		return -1;

	return 0;
}

#elif defined(_WIN32)

HANDLE so_fileno(SO_FILE* stream)
{
	return stream->fd;
}

SO_FILE* so_fopen(const char* pathname, const char* mode)
{
	SO_FILE* stream = (SO_FILE*)malloc(sizeof(SO_FILE));
	mode_t mode2 = S_IRWXU | S_IRWXG | S_IRWXO;
	stream->size = stream->pos = 0;
	if (strcmp(mode, "r") == 0) {
		stream->fd = CreateFile(pathname, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
		stream->bufmode = 0;
	}
	else if (strcmp(mode, "r+") == 0) {
		stream->fd = CreateFile(pathname, GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
		stream->bufmode = 0;
	}
	else if (strcmp(mode, "w") == 0) {
		stream->fd = CreateFile(pathname, GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
		stream->bufmode = 1;
	}
	else if (strcmp(mode, "w+") == 0) {
		stream->fd = CreateFile(pathname, GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
		stream->bufmode = 1;
	}
	else if (strcmp(mode, "a") == 0) {
		stream->fd = CreateFile(pathname, FILE_APPEND_DATA, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
		stream->bufmode = 1;
	}
	else if (strcmp(mode, "a+") == 0) {
		stream->fd = CreateFile(pathname, GENERIC_READ | FILE_APPEND_DATA, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
		stream->bufmode = 1;
	}
	else
	{
		free(stream);
		return NULL;
	}

	if (stream->fd == INVALID_HANDLE_VALUE) {
		free(stream);
		return NULL;
	}

	return stream;
}

BOOL wbytes(HANDLE handle, const void* buf, size_t count, int* bytes_written)
{
	size_t totalbytes = 0;
	BOOL ret;

	while (totalbytes < count) {
		size_t bytes_written_now;

		ret = WriteFile(handle, (char*)buf + totalbytes,
			count - totalbytes,
			&bytes_written_now, NULL);

		if (ret == FALSE) 
			return FALSE;

		totalbytes += bytes_written_now;
	}

	*bytes_written = totalbytes;
	return TRUE;
}

int dump_in_buffer(SO_FILE* stream)
{
	BOOL ret;
	int dumped;

	ret = ReadFile(stream->fd, stream->buffer, SO_BUFSIZE, &dumped, NULL);

	if (ret == FALSE) {
		stream->rerror = SO_EOF;
		return -1;
	}

	stream->size = dumped;
	stream->pos = 0;
	if (dumped > 0)
		stream->rerror = 0;
	else
		stream->rerror = SO_EOF;

	return dumped;
}

int dump_out_buffer(SO_FILE* stream)
{
	BOOL ret;
	int dumped;

	ret = xwrite(stream->fd, stream->buffer, stream->pos, &dumped);
	stream->pos = 0;

	if (ret == FALSE) {
		stream->werror = SO_EOF;
		return -1;
	}

	return dumped;
}

int so_fclose(SO_FILE* stream)
{
	int val;

	if (stream->bufmode==1 && stream->pos != 0) {
		val = dump_out_buffer(stream);
		if (val <= 0) {
			CloseHandle(stream->fd);
			free(stream);
			return val;
		}
	}
	val = CloseHandle(stream->fd);
	if (val != 0)
		return -1;
	free(stream);

	return 0;
}


int so_fseek(SO_FILE* stream, long offset, int whence)
{
	int check;
	int off;

	if (stream->bufmode == 1 && stream->pos != 0) {
		check = dump_out_buffer(stream);
		if (check <= 0)
			return -1;
		stream->pos = 0;
	}

	if (stream->bufmode == 0 && whence == SEEK_CUR)
		offset -= (stream->size - stream->pos);
	stream->pos = 0;
	stream->size = 0;

	off = SetFilePointer(stream->fd, offset, NULL, whence);
	return (off == INVALID_SET_FILE_POINTER) ? -1 : 0;
}

long so_ftell(SO_FILE* stream)
{
	long off;

	off = SetFilePointer(stream->fd, 0, NULL, SEEK_CUR);
	if (off == INVALID_SET_FILE_POINTER)
		return -1;

	if (stream->bufmode == 0 && stream->size != 0)
		off = off - (stream->size - stream->pos);

	if (stream->bufmode == 1 && stream->pos != 0)
		off = off + stream->pos;

	return off;
}

size_t so_fread(void* ptr, size_t size, size_t nmemb, SO_FILE* stream)
{
	if (stream->bufmode == 1)
	{
		LPDWORD flags;
		GetHandleInformation(stream->fd, flags);

		if ((long int)flags & GENERIC_READ)
		{
			dump_out_buffer(stream);
			stream->pos = 0;
			stream->bufmode = 0;
		}
		else
			return -1;
	}

	int i, offset = 0, bytes_loaded;
	size_t to_read, membct = 0;

	for (i = 0; i < nmemb; i++) {
		size_t bytes_read_now = 0;

		while (bytes_read_now < size) {
			if (stream->pos == stream->size) {
				bytes_loaded = dump_in_buffer(stream);
				if (bytes_loaded < 0)
					return 0;
				if (bytes_loaded == 0)
					return membct;
			}

			to_read = size;
			if (stream->size - stream->pos < to_read)
				to_read = stream->size - stream->pos;

			memcpy((char*)ptr + offset, stream->buffer + stream->pos, to_read);
			stream->pos += to_read;
			bytes_read_now += to_read;
			offset += to_read;
		}

		if (bytes_read_now > 0)
			membct++;
	}

	return membct;
}

size_t so_fwrite(const void* ptr, size_t size, size_t nmemb, SO_FILE* stream)
{
	if (stream->bufmode == 0)
	{
		LPDWORD flags;
		GetHandleInformation(stream->fd, flags);

		if ((long int)flags & GENERIC_WRITE)
		{
			dump_out_buffer(stream);
			stream->pos = 0;
			stream->size = 0;
			stream->bufmode = 1;
		}
		else
			return -1;
	}

	int i, offset = 0, bytes_unloaded;
	size_t to_write, membct = 0;

	for (i = 0; i < nmemb; i++) {
		size_t bytes_wrote_now = 0;

		while (bytes_wrote_now < size) {
			if (stream->pos == SO_BUFSIZE) {
				bytes_unloaded = dump_out_buffer(stream);
				if (bytes_unloaded <= 0)
					return 0;
			}

			to_write = size;
			if (SO_BUFSIZE - stream->pos < to_write)
				to_write = SO_BUFSIZE - stream->pos;

			memcpy(stream->buffer + stream->pos, (char*)ptr + offset, to_write);
			stream->pos += to_write;
			bytes_wrote_now += to_write;
			offset += to_write;
		}

		if (bytes_wrote_now > 0)
			membct++;
	}

	return membct;
}

int so_fputc(int c, SO_FILE* stream)
{
	if (stream->bufmode == 0)
	{
		LPDWORD flags;
		GetHandleInformation(stream->fd, flags);

		if ((long int)flags & GENERIC_WRITE)
		{
			dump_in_buffer(stream);
			stream->pos = 0;
			stream->size = 0;
			stream->bufmode = 0;
		}
		else
			return -1;
	}
	int check;

	if (stream->pos == SO_BUFSIZE) {
		check = dump_out_buffer(stream);
		if (check <= 0)
			return -1;
	}

	stream->buffer[stream->pos] = (char)c;
	(stream->pos)++;

	return c;
}

int so_fgetc(SO_FILE* stream)
{
	if (stream->bufmode == 1)
	{
		LPDWORD flags;
		GetHandleInformation(stream->fd, flags);

		if ((long int)flags & GENERIC_READ)
		{
			dump_out_buffer(stream);
			stream->pos = 0;
			stream->bufmode = 0;
		}
		else
			return -1;
	}
	int check;
	char c;

	if (stream->pos == stream->size) {
		check = dump_in_buffer(stream);
		if (check <= 0)
			return -1;
	}

	c = stream->buffer[stream->pos];
	(stream->pos)++;

	return c;
}

int so_fflush(SO_FILE* stream)
{
	if (stream->bufmode == 0)
	{
		LPDWORD flags;
		GetHandleInformation(stream->fd, flags);

		if ((long int)flags & GENERIC_WRITE)
		{
			dump_out_buffer(stream);
			stream->pos = 0;
			stream->size = 0;
			stream->bufmode = 1;
		}
		else
			return -1;
	}
	int dumped;

	if (stream->pos != 0) {
		dumped = dump_out_buffer(stream);
		if (dumped <= 0)
			return -1;
	}

	return 0;
}

static VOID RedirectHandle(STARTUPINFO* psi, HANDLE hFile, INT opt)
{
	if (hFile == INVALID_HANDLE_VALUE)
		return;

	ZeroMemory(psi, sizeof(*psi));
	psi->cb = sizeof(*psi);

	psi->hStdInput = GetStdHandle(STD_INPUT_HANDLE);
	psi->hStdOutput = GetStdHandle(STD_OUTPUT_HANDLE);
	psi->hStdError = GetStdHandle(STD_ERROR_HANDLE);

	psi->dwFlags = psi->dwFlags | STARTF_USESTDHANDLES;

	switch (opt) {
	case STD_INPUT_HANDLE:
		psi->hStdInput = hFile;
		break;
	case STD_OUTPUT_HANDLE:
		psi->hStdOutput = hFile;
		break;
	case STD_ERROR_HANDLE:
		psi->hStdError = hFile;
		break;
	}
}

SO_FILE* so_popen(const char* command, const char* type)
{
	SO_FILE* stream;
	HANDLE rhandle, whandle;
	SECURITY_ATTRIBUTES sa;
	STARTUPINFO si;
	PROCESS_INFORMATION pi;
	BOOL ret;
	char commArgs[SO_BUFSIZE];

	strcpy(commArgs, "C:\\windows\\system32\\cmd.exe /c ");
	strcat(commArgs, command);

	stream = (SO_FILE*)malloc(sizeof(SO_FILE));
	if (stream == NULL)
		return NULL;

	if (strcmp(type, "r") != 0 && strcmp(type, "w") != 0) {
		free(stream);
		return NULL;
	}

	ZeroMemory(&sa, sizeof(sa));
	sa.nLength = sizeof(SECURITY_ATTRIBUTES);
	sa.bInheritHandle = TRUE;

	ZeroMemory(&pi, sizeof(pi));

	GetStartupInfo(&si);

	ret = CreatePipe(&rhandle, &whandle, &sa, 0);
	if (ret == FALSE) {
		free(stream);
		return NULL;
	}

	if (strcmp(type, "r") == 0) {
		stream->fd = rhandle;
		RedirectHandle(&si, whandle, STD_OUTPUT_HANDLE);
		ret = SetHandleInformation(rhandle, HANDLE_FLAG_INHERIT, 0);
	}
	else if (strcmp(type, "w") == 0) {
		stream->fd = whandle;
		RedirectHandle(&si, rhandle, STD_INPUT_HANDLE);
		si.hStdInput = rhandle;
		ret = SetHandleInformation(whandle, HANDLE_FLAG_INHERIT, 0);
	}

	ret = CreateProcess(NULL, commArgs, NULL, NULL, TRUE, 0, NULL, NULL, &si, &pi);

	if (strcmp(type, "r") == 0)
		CloseHandle(whandle);
	else
		CloseHandle(rhandle);

	if (ret == 0) {
		free(stream);
		return NULL;
	}

	stream->process = pi;
	return stream;
}

int so_pclose(SO_FILE* stream)
{
	int check;
	BOOL ret;
	PROCESS_INFORMATION pi = stream->process;
	HANDLE handle = stream->fd;

	if (stream->bufmode == 1 && stream->pos != 0) {
		check = dump_out_buffer(stream);
		if (check <= 0) {
			free(stream);
			return check;
		}
	}

	free(stream);

	check = CloseHandle(handle);

	ret = WaitForSingleObject(pi.hProcess, INFINITE);
	if (ret == WAIT_FAILED) {
		printf("last error %d\n", GetLastError());
		return -1;
	}

	CloseHandle(pi.hProcess);
	CloseHandle(pi.hThread);

	return 0;
}
#endif

//comune
int so_ferror(SO_FILE* stream)
{
	return (stream->rerror | stream->werror);
}

int so_feof(SO_FILE* stream)
{
	return stream->rerror;
}